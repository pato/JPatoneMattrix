package patonemattrix;
import static java.lang.System.*;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        // TODO code application logic here
    }

}
